# RxExam — Ujian Menulis Resep

A standalone, mobile-first prototype for a prescription-writing exam interface. This repository is separate from the TBS simulation application.

## Prototype status

This repository is the cleaned RxExam source. Manus-specific runtime, debug collector, storage proxy, and related scaffolding have been removed; the RxExam application code and authentication/exam flows are retained.


This build follows the RxExam reference UI supplied by the user. It uses synthetic demo records only. The Google sign-in, student verification, instructor role, exam storage, autosave, and audit events are simulations implemented in the browser. Answer drafts are stored locally with `localStorage`; nothing is sent to Supabase or another backend. The student demo pair is `demo.student@gmail.com` and `2408101017`. The lecturer-only demo entry credentials are shown on the `/admin` sign-in page. Neither demo path is production authentication or access control.

No clinical prescription answer, treatment recommendation, or answer key is included. Browser-only anti-cheating monitoring cannot guarantee prevention. The `/security` view and [Supabase integration notes](docs/supabase-integration.md) document production requirements.

## Routes

| Route | Prototype view |
| --- | --- |
| `/login` | Student Google-login placeholder and separate instructor demo entry |
| `/verify-student` | Email + NIM demo verification |
| `/exam` | Assessment instructions followed by three timed cases, structured prescription fields, local autosave, and submit confirmation |
| `/submitted` | Local submission receipt and restart demo action |
| `/admin` | Role-gated demo participant list, answer-review state, and audit-log UI |
| `/security` | Security limitations and Supabase integration expectations |

The `/admin` route is not presented as production-secure. In the prototype, role state is local; production must enforce instructor authorization on the server for every operation.

## Run locally

From this directory:

```bash
pnpm install
pnpm dev
```

Build and type-check:

```bash
pnpm check
pnpm build
```

The WebDev static project includes a route fallback for the required standalone paths. For another static host, configure history fallback to `index.html` and deploy the built frontend bundle.

## Backend integration

The app is intentionally disconnected. Review [docs/supabase-schema.sql](docs/supabase-schema.sql) and [docs/supabase-integration.md](docs/supabase-integration.md) before connecting a Supabase project. Do not place a service-role key in frontend code or a `VITE_*` variable. Keep integration secrets out of source control and only connect after server-side auth, RLS, and acceptance tests are complete.
